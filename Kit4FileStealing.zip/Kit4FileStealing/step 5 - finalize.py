def main():
	target_class_path = input("Target class path: ").replace("\\", "\\\\")
	target_activity = input("First line (i.e. Lcom/xxx/xxx;): ")
	server = input("Your server domain name (abc.com): ")

	regex = "Lchange/this_path_to_the_path_of_the_class_that_you_plan_to_modify/MainActivity;"

	out = open(target_class_path, "r").read().replace(regex, target_activity).replace("{localhost}", server)
	open(target_class_path, "w").write(out)
	print("write ok.")
	main()

main()
