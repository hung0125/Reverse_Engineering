package com.five00iq.snippet;

import android.app.*;
import android.content.*;
import android.content.res.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.widget.AdapterView.*;
import java.io.*;
import java.util.*;
import org.apache.http.*;
import org.apache.http.client.*;
import org.apache.http.client.methods.*;
import org.apache.http.impl.client.*;
import org.apache.http.util.*;

public class SnippetActivity extends Activity 
{
	public int m_mod;
	public int pos;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.snippetview);
		
		if(android.os.Build.VERSION.SDK_INT > 9)
		{
			StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
			StrictMode.setThreadPolicy(policy);
		}
		
		ListView a = findViewById(R.id.snippetList);
		Button c = findViewById(R.id.change);
		Button d = findViewById(R.id.showMethod);
		Button e = findViewById(R.id.showCaller);
		
		
		final String[] snippets = {
			"Go to GitHub",
			"Alert",
			"LoadAUrl",
			"PlayAnAudio",
			"ShowToast",
			"SplitSentenceIntoToasts",
			"LoadManyUrl",
			"Uninstall",
			"BrowserBomb100",
			"GetUserInfo",
			"MassiveFileCreator"
		};
		
		final List<String> snippet_list = new ArrayList<String>(Arrays.asList(snippets));
		final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, snippet_list);
		a.setAdapter(arrayAdapter);
		
		a.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					
				EditText f = findViewById(R.id.snippetOutput);
				Button c = findViewById(R.id.change);
				Button d = findViewById(R.id.showMethod);
				Button e = findViewById(R.id.showCaller);
				
				if(position > 0)
				{
					d.setClickable(true);
					d.setText("Method");
					e.setClickable(true);
					e.setText("Caller");
					//Toast.makeText(SnippetActivity.this, "Chose " + snippets[position] + "\nThen enter your target activity path. :)", 2000).show();
				}
				
				m_mod = position;
				//config clickable
				if(getOutput(position,0,snippets).contains("[Insert activity here]"))
				{
					c.setClickable(true);
					c.setText("Change");
				}else
				{
					c.setClickable(false);
					c.setText("-");
				}
				
				switch(position){
					case 0:
						Intent i = new Intent(Intent.ACTION_VIEW);
						i.setData(Uri.parse("https://github.com/hung0125/Reverse_Engineering/tree/master/tutorials/smali_injection"));
						startActivity(i);
						break;
					default:
						f.setText(getOutput(position,0,snippets));
						pos = position;
						break;
				}
			}
		});
		
		c.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v)
			{
				EditText f = findViewById(R.id.snippetOutput);
				EditText b = findViewById(R.id.activityReplace);
				
				String code = f.getText().toString();
				
				if(code.contains("[Insert activity here]")){
					if(b.getText().toString().length() > 0)
					{
						code = code.replace("[Insert activity here]", b.getText().toString());
						Toast.makeText(SnippetActivity.this, "Changed", 1000).show();
					}else
					{
						Toast.makeText(SnippetActivity.this, "Empty input is not accepted.", 1000).show();
					}
					
				}else{
					Toast.makeText(SnippetActivity.this, "Nothing has changed.", 1000).show();
				}
				
				f.setText(code);
				
			}
		});
		
		c.setClickable(false);
		c.setText("-");
		
		d.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v)
			{
				EditText f = findViewById(R.id.snippetOutput);
				Button c = findViewById(R.id.change);
				
				if(getOutput(pos,0,snippets).contains("[Insert activity here]"))
				{
					c.setClickable(true);
					c.setText("Change");
				}else
				{
					c.setClickable(false);
					c.setText("-");
				}
					
				f.setText(getOutput(pos,0,snippets));
					
			}
		});
		
		d.setClickable(false);
		d.setText("-");
		
		e.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v)
			{
				EditText f = findViewById(R.id.snippetOutput);
				Button c = findViewById(R.id.change);
				c.setClickable(true);
				c.setText("Change");
				f.setText(getOutput(pos,1,snippets));
			}
		});
		
		e.setClickable(false);
		e.setText("-");
		
	}

	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		Intent i = new Intent(SnippetActivity.this, MainActivity.class);
		startActivity(i);
		this.finish();
	}
	private String getOutput(int pos, int method_caller, String[] snippets)
	{
		String a = "";
		String line = "";
		if(method_caller == 0)
		{
			try {
				InputStream fIn = getApplicationContext().getResources().getAssets().open(snippets[pos] + ".txt", Context.MODE_WORLD_READABLE);

				BufferedReader input = new BufferedReader(new InputStreamReader(fIn));
				
				while ((line = input.readLine()) != null) {
					// process the line..
					a += line +"\n";
				}
			} catch (Exception e) {}
			return a;
		}else
		{
			try {
				InputStream fIn = getApplicationContext().getResources().getAssets().open("C_" + snippets[pos] + ".txt", Context.MODE_WORLD_READABLE);

				BufferedReader input = new BufferedReader(new InputStreamReader(fIn));
			
				while ((line = input.readLine()) != null) {
					// process the line..
					a += line +"\n";
				}
			} catch (Exception e) {}
			return a;
		}
		
		
	}
}
