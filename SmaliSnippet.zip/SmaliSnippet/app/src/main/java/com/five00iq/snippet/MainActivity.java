package com.five00iq.snippet;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity 
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

		Button snippet = findViewById(R.id.snippet);
		Button github = findViewById(R.id.github);
		Button youtube = findViewById(R.id.youtube);
		
		
		snippet.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v)
			{
				Intent intent = new Intent(MainActivity.this, SnippetActivity.class);
				startActivity(intent);
				MainActivity.this.finish();
			}
		});

		github.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v)
			{
				Intent i = new Intent(Intent.ACTION_VIEW);
				i.setData(Uri.parse("https://github.com/hung0125/Reverse_Engineering/tree/master/tutorials/smali_injection"));
				startActivity(i);
			}
		});
		
		youtube.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v)
			{
				Intent i = new Intent(Intent.ACTION_VIEW);
				i.setData(Uri.parse("https://www.youtube.com/channel/UCOc7VWy6tkeTSiOeOzqNqgA"));
				startActivity(i);
			}
		});
		
		
	}
	
	@Override
	public void onBackPressed()
	{
		// TODO: Implement this method
		//Toast.makeText(this, "One more time to exit", 1000).show();
		this.finish();
	}
}
